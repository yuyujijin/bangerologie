// Include the cluster module
var cluster = require('cluster');

// Code to run if we're in the master process
if (cluster.isMaster) {

    // Count the machine's CPUs
    var cpuCount = require('os').cpus().length;

    // Create a worker for each CPU
    for (var i = 0; i < cpuCount; i += 1) {
        cluster.fork();
    }

    // Listen for terminating workers
    cluster.on('exit', function (worker) {

        // Replace the terminated workers
        console.log('Worker ' + worker.id + ' died :(');
        cluster.fork();

    });

    // Code to run if we're in a worker process
} else {
    var AWS = require('aws-sdk');
    var express = require('express');
    var bodyParser = require('body-parser');

    // AWS.config.region = process.env.REGION
    const SESConfig = {
        accessKeyId: process.env.AWS_ACCESS_ID,
        secretAccessKey: process.env.AWS_SECRET_KEY,
        region: "us-east-1"
    }

    AWS.config.update(SESConfig);

    var sns = new AWS.SNS();
    var ddb = new AWS.DynamoDB();

    var ddbTable = process.env.STARTUP_SIGNUP_TABLE;
    var snsTopic = process.env.NEW_SIGNUP_TOPIC;
    var app = express();

    app.set('view engine', 'ejs');
    app.set('views', __dirname + '/views');
    app.use(bodyParser.urlencoded({ extended: false }));

    app.get('/', function (req, res) {
        res.render('empty', {
            static_path: 'static',
            theme: process.env.THEME || 'flatly',
            flask_debug: process.env.FLASK_DEBUG || 'false'
        });
    });

    app.get('/colocathon', function (req, res) {

        var params = {
            TableName: "colocathon-team"
        };

        ddb.scan(params, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                var items = [];
                for (var i in data.Items)
                    items.push(data.Items[i]['Name']);

                res.render('colocathon', {
                    static_path: 'static',
                    theme: process.env.THEME || 'flatly',
                    flask_debug: process.env.FLASK_DEBUG || 'false',
                    teams: items,
                });
            }
        });


    });

    var port = process.env.PORT || 3000;

    var server = app.listen(port, function () {
        console.log('Server running at http://127.0.0.1:' + port + '/');
    });
}